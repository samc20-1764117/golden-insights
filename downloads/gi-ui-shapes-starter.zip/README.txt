Golden Insights — UI Shapes Starter Pack
20 transparent PNG shapes (256x256) for Tableau dashboards.

To install in Tableau:
1. Copy the PNGs into a new folder inside:  Documents/My Tableau Repository/Shapes/Golden Insights
2. In Tableau, drag a field to Shape, click Shape -> More Shapes -> Reload Shapes
3. Pick the Golden Insights palette and assign away!
